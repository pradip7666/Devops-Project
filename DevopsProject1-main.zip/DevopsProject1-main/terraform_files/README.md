### TERRAFORM FILES
---

![image](https://github.com/pandacloud1/DevopsProject1/assets/134182273/42370753-d725-4706-a0fa-39d5281e6546)

#### The above Terraform files will create 'Jenkins' & 'K8s' servers
#### Master-Server --> Git, Maven, Docker, Trivy, Ansible
#### Node-Server --> Docker, K8s (Kubeadm)

##### *NOTE*:
1. Create a 'My_key.pem' from AWS EC2 console 
2. Save the key file in the same location as your terraform code
