sudo yum update -y
sudo yum install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm -y
sudo yum install git python python-devel python-pip openssl ansible -y
