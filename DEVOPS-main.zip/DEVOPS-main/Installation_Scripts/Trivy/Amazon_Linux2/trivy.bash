#!/bin/bash
# REF: https://aquasecurity.github.io/trivy/v0.18.3/installation/
sudo rpm -ivh https://github.com/aquasecurity/trivy/releases/download/v0.18.3/trivy_0.18.3_Linux-64bit.rpm
